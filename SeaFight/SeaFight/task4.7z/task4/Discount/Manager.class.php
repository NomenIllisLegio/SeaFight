<?php

/**
 *
 * Class Discount_Manager
 */
class Discount_Manager
{
    private $discounts = array();
    private $order;
	private $discountSum = 0;
	private $currentDiscount;
	
    public function setOrder(Order $order)
    {
        $this->order = $order;
    }

    public function addDiscount(Discount ...$discount)
    {
        $this->discounts[] = $discount;
    }

    public function getDiscount()
    {
        return $this->discounts;
    }

    public function doCalculation()
    {
        $this->$discountSum = 0;
        foreach ($this->discounts as $discount) {
            $this->$discountSum += checkOrderDiscount($discount);
        }
        return $this->$discountSum
    }
	
	private function checkOrderDiscount(Discount $discount)
	{	
		$sum = 0;
		$this->$currentDiscount = $discount;
		
		switch($discount->$type)
		{
			case "products":
				$sum = $this->calculateProductsSet($sum);
				break;
			case "main_products":
				$sum = $this->calculateMainProuductSet();
				break;
			case "count_products":
				$sum = $this->calculateCountProducts();
				break;
			default
		}
		return $sum;
	}
	
	private function calculateProductsSet($sum)
	{	
		$productsInDiscount = $this->$currentDiscount->getProductSet();
		
		$findProductInOrder = array();
		
		foreach($productsInDiscount as $productSet)
		{
			foreach($this->$order as $productInOrder)
			{
				if($productInOrder['product'] == $productSet && $productInOrder['isDiscounted'] == 0 )
				{
					$findProductInOrder[] = &$productInOrder['product'];
				}
			}
		}
		
		if(count($findProductInOrder) == count($this->productsSet)) 
		{
            foreach($findProductInOrder as &$discountProduct) 
			{
                $discountProduct['isDiscounted'] = 1;
                $sum += $discountProduct['product']->getPrice();
            }
			return $this->calculateProductsSet($sum);
        }
		
		return $sum * $currentDiscount->getDiscount();
	}
	
	private function calculateMainProuductSet()
	{	
		$mainProductInDiscount  = $this->$currentDiscount->getMainProduct();
		$dependentProducts		= $this->$currentDiscount->getDependentProducts();
		$findProductInOrder 	= array();
		$isFindMainProduct		= false;
		$sum					= 0;
		
		if(!is_object($mainProductInDiscount) || count($dependentProducts) == 0) 
		{
            return $sum;
        }
		
		foreach($this->$order as $productInOrder)
		{
			if($productInOrder['product'] == $mainProductInDiscount)
			{
				$isFindMainProduct = true;
			}
		}	
		
		if( $isFindMainProduct )
		{	
			foreach($this->$order as $productInOrder)
			{
				foreach($this->$order as $productInOrder)
				{	
					$productInOrder['isDiscounted'] = 1;
					$sum += $productInOrder['product']->getPrice();
				}
			}
		}
		else
		{
			return $sum;
		}

		return $sum * $currentDiscount->getDiscount();
	}
	
	private function calculateCountProducts()
	{	
		$count 				= 0;
		$sum 				= 0;
		$exceptedProducts 	= $this->currentDiscount->getExpectedProduct();
		$discountRule 		= $this->currentDiscount->getDiscountRule();
		
		foreach($exceptedProducts as $product)
		{	
			foreach($this->order as $productInOrder)
			{
				if( $productInOrder['product'] != $product )
				{
					$count++;
					$sum += $productInOrder['product']->getPrice();
					$productInOrder['isDiscounted'] = 1;
				}
			}
		}
		
		if(array_key_exists($count, $discountRule)) 
		{
			$sum *= $discountRule[$count];
        }
		
		return $sum;
	}
}