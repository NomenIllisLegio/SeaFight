<?php

/**
 * Class Order
 */
class Order
{
    public $products = array();

    public function addProduct(Product ...$productData)
    {	
		foreach( $productData as $product)
		{
			$this->products[] = array(
				'product' => $product,
				'isDiscounted' => 0,
			);
		} 
    }
	
    public function getProducts() 
	{
        return $this->products;
    }
}
