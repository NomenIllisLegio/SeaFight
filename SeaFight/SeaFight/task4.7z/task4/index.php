<?php

 spl_autoload_register(function ($class) {
     $class = str_replace('_', '/', $class);
     include $class . '.class.php';
 });

// Create product items
$productA = new Product('A', 100);
$productB = new Product('B', 100);
$productC = new Product('C', 100);
$productD = new Product('D', 100);
$productE = new Product('E', 100);
$productF = new Product('F', 100);
$productG = new Product('G', 100);
$productH = new Product('H', 100);
$productI = new Product('I', 100);
$productJ = new Product('J', 100);
$productK = new Product('K', 100);
$productL = new Product('L', 100);
$productM = new Product('M', 100);

//Create order
$order = new Order();
$order->addProduct($productA);

$discount1 = new Discount_ProductSet();
$discount1->setProductSet($productA, $productB);
$discount1->setDiscount(10);

$discount2 = new Discount_ProductSet();
$discount2->setProductSet($productD, $productE);
$discount2->setDiscount(5);

$discount3 = new Discount_ProductSet();
$discount3->setProductSet($productE, $productF, $productG);
$discount3->setDiscount(5);

//Discount by dependent
$discount4 = new Discount_DependentProductSet();
$discount4->setMainProduct($productA);
$discount4->setDependentProduct($productK,$productL,$productM);
$discount4->setDiscount(5);

//Discount by count
$discount5 = new Discount_CountProductSet();
$discount5->addExpectedProduct($productA,$productC);
$discount5->addDiscountRule(3, 5);
$discount5->addDiscountRule(4, 10);
$discount5->addDiscountRule(5, 20);

//Add discount
$discountManager = new Discount_Manager();
$discountManager->addDiscount( $discount1, $discount2, $discount3, $discount4, $discount5 );

//Do calculation
$calculator = new Calculator();
$calculator->setOrder($order);
$calculator->setDiscountManager($discountManager);
$amount = $calculator->doCalculation();

echo "Total amount: " . $amount;

