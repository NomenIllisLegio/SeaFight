<?php

/**
 * Class Discount
 */
abstract class Discount
{
    protected $discount = 1;
    protected $order;
	protected $type = "products"; //"products", "main_products", "count_products"
	
    abstract function doCalculation();

    public function  setDiscount($discount)
    {
        $this->discount = 1 - $discount/100;
    }

    public function getDiscount()
    {
        return $this->discount;
    }

    public function setOrder(Order $order)
    {
        $this->order = $order;
    }
	
	public function getDiscountType()
	{
		return this->$type;
	}
}
